ALTER TABLE `strains` ADD `vegaWeeks` int DEFAULT 4 NOT NULL;--> statement-breakpoint
ALTER TABLE `strains` ADD `floraWeeks` int DEFAULT 8 NOT NULL;