ALTER TABLE `dailyLogs` ADD `ph` decimal(3,1);--> statement-breakpoint
ALTER TABLE `dailyLogs` ADD `ec` decimal(4,2);