ALTER TABLE `weeklyTargets` ADD `photoperiod` varchar(10);--> statement-breakpoint
ALTER TABLE `weeklyTargets` ADD `phMin` decimal(3,1);--> statement-breakpoint
ALTER TABLE `weeklyTargets` ADD `phMax` decimal(3,1);--> statement-breakpoint
ALTER TABLE `weeklyTargets` ADD `ecMin` decimal(3,1);--> statement-breakpoint
ALTER TABLE `weeklyTargets` ADD `ecMax` decimal(3,1);