DROP TABLE `alertHistory`;--> statement-breakpoint
DROP TABLE `alertSettings`;--> statement-breakpoint
DROP TABLE `alerts`;--> statement-breakpoint
DROP TABLE `cloningEvents`;--> statement-breakpoint
DROP TABLE `cycles`;--> statement-breakpoint
DROP TABLE `dailyLogs`;--> statement-breakpoint
DROP TABLE `recipeTemplates`;--> statement-breakpoint
DROP TABLE `recipes`;--> statement-breakpoint
DROP TABLE `safetyLimits`;--> statement-breakpoint
DROP TABLE `strains`;--> statement-breakpoint
DROP TABLE `taskInstances`;--> statement-breakpoint
DROP TABLE `taskTemplates`;--> statement-breakpoint
DROP TABLE `tentAState`;--> statement-breakpoint
DROP TABLE `tents`;--> statement-breakpoint
DROP TABLE `users`;--> statement-breakpoint
DROP TABLE `weeklyTargets`;